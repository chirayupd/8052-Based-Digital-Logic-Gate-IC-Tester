#include<reg51.h>
sbit RS=P1^4;
sbit rw=P1^5;
sbit EN=P1^6;
 
void lcdcmd(unsigned char);
void lcddata(unsigned char);
void lcdstring(unsigned char *S);
void delay(unsigned int);
void nandg();
void norg();
void andg();
void org();
void exorg();
void exnorg();
void notg();
unsigned int kb();
void iclist();
void check();
void good();
void bad();

/********** MAIN Program ********/
void main(void)
	{
		unsigned char n,n1;
		lcdcmd(0x38);
		lcdcmd(0x0E);
		lcdcmd(0x01);
		lcdcmd(0x80);
		lcdstring("WELCOME TO IC..");
		lcdcmd(0xC0);
		lcdstring("TESTING PROGRAM");
		delay(200);
		lcdcmd(0x01);
		lcdcmd(0x80);
		lcdstring("BY CHIRAYU EC12");
		lcdcmd(0xC0);
		lcdstring("ADITYA EC11");
		delay(200);
		lcdcmd(0x01);
		lcdcmd(0x80);
		lcdstring("--Read IC list--");
		//lcdcmd(0xC0);
		//lcdstring("-Then press key-");
		//delay(200);
		n=-1;
		while (n == -1)//reads the key pressed from keypad and stores it in number
		{
			iclist();
			n = kb();	 		
		}	
				back: //lcdcmd(0x01);
				//lcdcmd(0x80);
				//lcdstring("You pressed: ");
				//lcdcmd(0x8E);
				//lcddata(n);
				//lcdcmd(0xC0);
				//lcdstring("---Thank you---");
				delay(100);				
				if (n != -1)	  //if there is a number pressed then displays on LCD -1 means no button is pressed
				{
	same: 	//delay(100);
					switch (n)
					{
						case '1': nandg();
						break;
						case '2': norg();
						break;
						case '3': notg();
						break;
						case '4': andg();
						break;
						case '5': org();
						break;
						case '6': exorg();
						break;
						case '7': exnorg();
						break;
						case '0': check();
						break;
						default:  lcdcmd(0x01);
						lcdcmd(0x80);
	//lcdstring("You pressed...");
//lcdcmd(0xC0);
	//lcdstring("another key: ");
	//lcdcmd(0xCD);
	lcddata(n);
	delay(100);
//lcdcmd(0x01);
//lcdcmd(0x80);
//lcdstring("--Read IC list--");
//lcdcmd(0xC0);
//lcdstring("-Then press key-");
//delay(200);
iclist();
break;
	}
	}
	n1=kb();
	if(n1==-1)
		goto same;
		else
		{
		n=n1;
		goto back;
	}
	}		 
void check()
	{
		unsigned char i,a,b,c,d,in[]={0x00,0x0F,0xF0,0xFF},y1[4];
		P1=0x0F;
		a=0;
		lcdcmd(0x01);
		lcdcmd(0x80);	
		for(i=0;i<4;i++)	
			{
				P2=in[i];//inputs to AND gate
				y1[i]=P1;
				if (y1[i]==0x00)
					a=a<<1;
				if (y1[i]==0x0F)
					{
						a=a<<1;
						a++;
					}
			}
			//AND=(0001)=1, OR=(0111)=7, NAND=(1110)=14, EXOR=(0110)=6
			if(a==1)
			{
				lcdstring("IC7408: AND Gate");
				delay(1000);
				return;
			}
			if(a==7)
			{
				lcdstring("IC7432: OR Gate");
				delay(1000);
				return;
			}
			if(a==14)
			{
				lcdstring("IC7400:NAND Gate");
				delay(1000);
				return;
			}
			if(a==6)
			{
				lcdstring("IC7486: XOR Gate");
				delay(500);
				return;
			}
				a=0;
		P2=0xFF;	// B inputs to NOR gate
		P1=0x0F;	// A inputs to NOR gate
		a=P2;		// a==0x0F ("Good!! IC");
		if(a==0x0F)
			{
				lcdstring("IC7402: NOR Gate");
				delay(1000);
				return;
			}
		//NOT gate testing
		P2=0x69;//inputs to NOT gate
		P1=0x06;//inputs to NOT gate
		b=P2;
		c=P1;
		a=b+c;
		if (a==0x6F)	
		{
			P2=0xFF;//inputs to NOT gate
			P1=0x0F;//inputs to NOT gate
			b=P2;
		c=P1;
		a=b+c;
		if (a==0x9F)	
				b=0x02; //NOT = (10)=2
		}
		P2=0xFF;//inputs to NOT gate
		P1=0x0F;//inputs to NOT gate
		c=P2;
		d=P1;
		b=c+d;
		if (b==0x9F)
			{
				lcdstring("IC7404: NOT Gate");
				delay(500);
				return;
			}
			lcdstring("Not matched with");
			lcdcmd(0xC0);
			lcdstring("our data base");
}
void iclist()
{
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("1:7400    2:7402");
	lcdcmd(0xC0);
	lcdstring("3:7404    4:7408");		
	delay(400);
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("5:7432    6:7486");
	lcdcmd(0xC0);
	lcdstring("7:74266   0:Auto");
	delay(400);
}
unsigned int kb()
	{
		P0=0x6F;
		if (P0 ==0x6E) //If row A gets low means 1 is pressed
    return '1';
		if (P0 ==0x6D) //If row B gets low means 4 is pressed
    return '4';
		if (P0 ==0x6B)  //If row C gets low means 7 is pressed
    return '7';
		if (P0 ==0x67)  //If row D gets low means * is pressed
    return '*';
	P0=0x5F;
		if (P0 ==0x5E)
    return '2';
		if (P0 ==0x5D)
    return '5';
		if (P0==0x5B)
    return '8';
		if (P0==0x57)
    return '0';

		P0=0x3F;
		if (P0 ==0x3E)
    return '3';
		if (P0==0x3D)
    return '6';
		if (P0 ==0x3B)
    return '9';
		if (P0==37)
    return '#';
		return -1;         //if no button is pressed return -1
  }
void lcdcmd(unsigned char value)
{
P3=value;
RS=0;
rw=0;
EN=1;
delay(2);
EN=0;
}
void lcddata(unsigned char value)
{
P3=value;
RS=1;
rw=0;
EN=1;
delay(5);
EN=0;
}
void lcdstring(unsigned char *S)
{
while(*S)
lcddata(*S++);
}
void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<t;i++)
for(j=0;j<1275;j++);
}
void andg()
{
	unsigned	char i,a=0,in[]={0x00,0x0F,0xF0,0xFF},y1[4],y3[]={0x00,0x00,0x00,0x0F};
P1=0x0f;
	for(i=0;i<4;i++)	
	{
		P2=in[i];//inputs to AND gate
		y1[i]=P1;
		if (y1[i]!=y3[i])	
		break;
		a++;
	}
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("***IC 7408***");
	delay(1000);
	if (a==4)
		good();
	else
		bad();
}
void org()
{
	unsigned	char i,a=0,in[]={0x00,0x0F,0xF0,0xFF},y1[4],y3[]={0x00,0x0F,0x0F,0x0F};
P1=0x0f;
	for(i=0;i<4;i++)	
	{
		P2=in[i];//inputs to OR gate
		y1[i]=P1;
		if (y1[i]!=y3[i])	
		break;
		a++;
	}
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("***IC 7432***");
	delay(500);
	if (a==4)
		good();
	else
		bad();
}
void nandg()
{
	unsigned	char i,a=0,in[]={0x00,0x0F,0xF0,0xFF},y1[4],y3[]={0x0F,0x0F,0x0F,0x00};
P1=0x0f;
	for(i=0;i<4;i++)	
	{
		P2=in[i];//inputs to NAND gate
		y1[i]=P1;
		if (y1[i]!=y3[i])	
		break;
		a++;
	}
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("***IC 7400***");
	delay(1000);
	if (a==4)
		good();
	else
		bad();
}
void exorg()
{
	unsigned char i,a=0,in[]={0x00,0x0F,0xF0,0xFF},y1[4],y3[]={0x00,0x0F,0x0F,0x00};
P1=0x0f;
	for(i=0;i<4;i++)	
	{
		P2=in[i];//inputs to EXOR gate
		y1[i]=P1;
		if (y1[i]!=y3[i])	
		break;
		a++;
	}
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("***IC 7486***");
	delay(1000);
	if (a==4)
		good();
	else
		bad();
}
void exnorg()
{
	unsigned char a=0, b=0;
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("***IC 74266***");
	delay(50);
	//P2=0x84;// B inputs to NOR gate
	//P1=0x04;// A inputs to NOR gate
	//a=P2;
	//P2=0x60;
	//P1=0x09;
	//a=P2;
	//b=P1;
	if(P2=0x60 && P1=0x09)
		good();
	//elseif(P2=0x1A && P1=0x02)
		good();
	//elseif(P2=0x85 && P1=0x04)
		good();
	//elseif(P2=0xFF && P1=0x0F)
		good();
	//else
		bad();
	//if (a==0x84)	
		//good();
	//else
		//bad();	
}
void norg()
{
	unsigned char a=0;
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("***IC 7402***");
	delay(50);
	P2=0xFF;// B inputs to NOR gate
	P1=0x0F;// A inputs to NOR gate
	a=P2;
	if (a==0x0F)	
		good();
	else
		bad();	
}
void notg()
{
	unsigned char a=0,y1,y2,y3;
		P2=0x69;//inputs to NOT gate
		P1=0x06;//inputs to NOT gate
		y1=P2;//69H
		y2=P1;//6
		y3=y1+y2;
		if (y3==0x6F)	
		a++;
		P2=0xFF;//inputs to NOT gate
		P1=0x0F;//inputs to NOT gate
		y1=P2;//96H
		y2=P1;//9
		y3=y1+y2;
		if (y3==0x9F)	
		a++;
	lcdcmd(0x01);
	lcdcmd(0x80);
	lcdstring("***IC 7404***");
		delay(1000);
	if (a==2)
		good();
	else
		bad();
}
void good()
{
	lcdcmd(0xC0);
	lcdstring("Good!! IC is OK");
	delay(1000);
}
void bad()
{
	lcdcmd(0xC0);
	lcdstring("Sorry!! BAD IC");
	delay(1000);
}